"""
Step 14 — Testing
Run from the project root:   pytest -v
"""
from fastapi.testclient import TestClient

from backend.main import app

client = TestClient(app)


# ---------- application functionality ----------
def test_health():
    r = client.get("/health")
    assert r.status_code == 200
    assert r.json() == {"status": "ok", "model_loaded": True}


def test_homepage_serves_frontend():
    r = client.get("/")
    assert r.status_code == 200
    assert "Crop Yield Predictor" in r.text


def test_static_files():
    assert client.get("/static/app.js").status_code == 200
    assert client.get("/static/style.css").status_code == 200


def test_meta_lists_both_countries():
    meta = client.get("/meta").json()
    assert set(meta["countries"]) == {"India", "China"}
    assert "Rice" in meta["crops_by_country"]["India"]
    assert meta["test_metrics"]["R2"] > 0.8


def test_temps_recorded_and_future():
    assert client.get("/temps/India/2020").json()["source"] == "recorded"
    assert "average" in client.get("/temps/India/2030").json()["source"]


def test_history():
    h = client.get("/history/China/Wheat").json()
    assert len(h["years"]) == len(h["yield_t_ha"]) > 20


# ---------- model predictions ----------
def predict(**kw):
    body = {"country": "India", "crop": "Rice", "year": 2024, "area_harvested_ha": 47_000_000, **kw}
    return client.post("/predict", json=body)


def test_predict_known_value_is_close():
    """India rice 2024 actual yield was ~4.31 t/ha; model should be within 15%."""
    r = predict()
    assert r.status_code == 200
    y = r.json()["predicted_yield_t_ha"]
    assert abs(y - 4.31) / 4.31 < 0.15


def test_predict_returns_production():
    d = predict().json()
    assert abs(d["estimated_production_t"] / (d["predicted_yield_t_ha"] * 47_000_000) - 1) < 1e-3


def test_predict_crop_differences_make_sense():
    """Sugar cane yields far more per hectare than lentils."""
    cane = predict(crop="Sugar cane", area_harvested_ha=5_000_000).json()["predicted_yield_t_ha"]
    lentil = predict(crop="Lentils, dry", area_harvested_ha=1_500_000).json()["predicted_yield_t_ha"]
    assert cane > 10 * lentil


def test_predict_future_year_uses_average_temps():
    d = predict(year=2027).json()
    assert d["predicted_yield_t_ha"] > 0
    assert "average" in d["temperature_source"]


def test_predict_custom_temperatures():
    temps = {k: 2.0 for k in ["temp_change_annual_c", "temp_change_djf_c", "temp_change_mam_c",
                              "temp_change_jja_c", "temp_change_son_c"]}
    d = predict(**temps).json()
    assert d["temperature_source"] == "user input"
    assert all(v == 2.0 for v in d["temperatures_used"].values())


# ---------- input validation ----------
def test_unknown_crop_rejected():
    assert predict(crop="Pizza").status_code == 422


def test_unknown_country_rejected():
    assert predict(country="Brazil").status_code == 422


def test_negative_area_rejected():
    assert predict(area_harvested_ha=-5).status_code == 422


def test_missing_field_rejected():
    assert client.post("/predict", json={"country": "India"}).status_code == 422
