@echo off
REM One-command local start (Windows)
cd /d %~dp0
if not exist .venv python -m venv .venv
call .venv\Scripts\activate
pip install -q -r requirements.txt
echo.
echo   Local URL:   http://127.0.0.1:8000
echo   API docs:    http://127.0.0.1:8000/docs
echo.
uvicorn backend.main:app --host 0.0.0.0 --port 8000 --reload
