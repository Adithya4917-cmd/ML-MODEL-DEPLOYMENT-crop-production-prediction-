# Crop Yield Predictor — India & China
End-to-end ML project following the **16-step "ML Model Design → URL Generation" flow**.

## Project structure
```
crop-yield-app/
├── data/df_perfect_india_china.csv     Step 2-3  merged & cleaned dataset (11,809 rows)
├── notebook/crop_yield_model.ipynb     Steps 1-10 problem → EDA → training → tuning → saving
├── model/
│   ├── crop_yield_model.joblib         Step 10   saved sklearn Pipeline (Random Forest)
│   ├── model_meta.json                 crop lists, temperatures, test metrics
│   └── yield_history.csv               history used by the chart
├── backend/main.py                     Step 11   FastAPI REST API
├── frontend/ (index.html, style.css, app.js)   Step 12  user interface
├── tests/test_api.py                   Step 14   15 pytest tests
├── requirements.txt · run.sh · run.bat
└── Dockerfile · render.yaml            Step 15   deployment configs
```

## Results (Steps 6-9)
Test set = years **2015–2024** (never seen in training).

| Model | R² | MAE (t/ha) | RMSE |
|---|---|---|---|
| **Random Forest** ✅ | **0.926** | **2.03** | **3.83** |
| Random Forest (tuned via RandomizedSearchCV) | 0.898 | 2.38 | 4.48 |
| Hist Gradient Boosting | 0.807 | 3.24 | 6.16 |
| Ridge Regression | 0.794 | 3.35 | 6.37 |
| Baseline (crop's historical average) | 0.671 | 4.30 | 8.04 |

Key design choices: `production_t` removed (it equals area × yield, so it leaks the answer); target trained as `log(1+yield)`;
time-based split instead of a random split.

---

## Steps 11–13: Backend, Frontend, Integration
* **Backend** (`backend/main.py`), FastAPI endpoints:

  | Method | Path | Purpose |
  |---|---|---|
  | GET | `/health` | server + model status |
  | GET | `/meta` | countries, crops, typical areas, metrics |
  | GET | `/temps/{country}/{year}` | recorded temps (or 5-yr average for future years) |
  | GET | `/history/{country}/{crop}` | actual yield series |
  | POST | `/predict` | **the prediction** |
  | GET | `/docs` | auto-generated Swagger UI |

* **Frontend** (`frontend/`): plain HTML/CSS/JS form + result tiles + interactive history chart.
* **Integration:** `app.js` calls the API with `fetch()`. FastAPI serves the frontend too, so one server = one URL.

Example request:
```bash
curl -X POST http://127.0.0.1:8000/predict -H "Content-Type: application/json" \
     -d '{"country":"India","crop":"Rice","year":2025,"area_harvested_ha":46449121}'
```

## Step 14: Testing
```bash
pytest -v
```
Covers: health, UI serving, metadata, a known prediction (India rice 2024 within 15% of actual),
sanity checks (sugar cane ≫ lentils), future years, custom temperatures, and bad-input rejection (422).

---

## Steps 15–16: Deployment & URL generation

### A. Local URL (your laptop)
```bash
# macOS/Linux                         # Windows
./run.sh                              run.bat
```
or manually:
```bash
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn backend.main:app --host 0.0.0.0 --port 8000 --reload
```
➡ **Local URL:** http://127.0.0.1:8000   ·   **API docs:** http://127.0.0.1:8000/docs

### B. LAN URL (anyone on the same Wi-Fi / lab network)
Find your IP (`ipconfig` on Windows, `ifconfig` / `ip a` on Mac/Linux), e.g. `192.168.1.25`
➡ **LAN URL:** `http://192.168.1.25:8000` (works because we start uvicorn with `--host 0.0.0.0`)

### C. Temporary public URL (tunnel, no account needed)
Keep the app running, then in a second terminal:
```bash
# Cloudflare Tunnel (install: https://developers.cloudflare.com/cloudflare-one/connections/connect-networks/downloads/)
cloudflared tunnel --url http://localhost:8000
# prints:  https://<random-words>.trycloudflare.com
```
or with ngrok (free account + authtoken):
```bash
ngrok http 8000
# prints:  https://<id>.ngrok-free.app
```
➡ **Public URL** that works from any phone or laptop for as long as your machine and the tunnel stay on.

### D. Permanent public URL (cloud: Render free tier)
1. Push the folder to a GitHub repo (the model file is ~43 MB, under GitHub's 100 MB limit).
2. On https://render.com → **New → Blueprint** → select the repo (it reads `render.yaml`).
3. Wait for the build → **Public URL:** `https://crop-yield-predictor.onrender.com` (or similar).

*Free instances sleep after inactivity; the first request may take ~30–60 s.*

### E. Docker (any cloud: Railway, Fly.io, Google Cloud Run, AWS…)
```bash
docker build -t crop-yield-app .
docker run -p 8000:8000 crop-yield-app      # → http://127.0.0.1:8000
```

---

## Re-training
Open `notebook/crop_yield_model.ipynb` and *Run All* (≈1–2 min). It overwrites the files in `model/`.
If you get a scikit-learn version warning when loading the model, re-run the notebook with your installed version.
