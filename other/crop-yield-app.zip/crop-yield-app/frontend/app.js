// Step 13 — Model Integration: the frontend talks to the FastAPI backend with fetch().
// API_BASE is empty when the page is served by FastAPI itself (same origin).
// If you host the frontend separately, set it to your backend URL, e.g. "https://my-api.onrender.com".
const API_BASE = "";

const $ = (id) => document.getElementById(id);
const TEMP_IDS = ["temp_change_annual_c", "temp_change_djf_c", "temp_change_mam_c", "temp_change_jja_c", "temp_change_son_c"];
const fmt = (n, d = 2) => Number(n).toLocaleString("en-IN", { maximumFractionDigits: d, minimumFractionDigits: d });
let META = null;
let tempsEdited = false;   // only send temperatures if the user changed them

async function api(path, options) {
  const res = await fetch(API_BASE + path, options);
  const body = await res.json().catch(() => ({}));
  if (!res.ok) {
    const msg = Array.isArray(body.detail) ? body.detail.map((d) => `${d.loc?.at(-1)}: ${d.msg}`).join("; ") : body.detail;
    throw new Error(msg || `Request failed (${res.status})`);
  }
  return body;
}

// ---------- form setup ----------
async function init() {
  try {
    META = await api("/meta");
  } catch (e) {
    $("error").textContent = "Cannot reach the API. Is the backend running? " + e.message;
    return;
  }
  $("country").innerHTML = META.countries.map((c) => `<option>${c}</option>`).join("");
  $("country").value = "India";
  fillCrops();
  $("crop").value = "Rice";
  fillArea();
  await fillTemps();

  const m = META.test_metrics, b = META.baseline_metrics;
  $("m-text").innerHTML =
    `<b>${META.model}</b>, trained on ${META.year_range[0]}–${META.year_range[1]}. ` +
    `On the held-out years 2015–2024 it scored <b>R² = ${m.R2.toFixed(3)}</b> and an average error of ` +
    `<b>${m.MAE.toFixed(2)} t/ha</b> (a simple “crop average” baseline: R² ${b.R2.toFixed(3)}, error ${b.MAE.toFixed(2)} t/ha). ` +
    `Predictions for years after ${META.year_range[1]} use recent average temperatures unless you enter your own, ` +
    `and are extrapolations, so treat them as estimates.`;

  $("country").addEventListener("change", () => { fillCrops(); fillArea(); fillTemps(); });
  $("crop").addEventListener("change", fillArea);
  $("year").addEventListener("change", fillTemps);
  $("form").addEventListener("submit", onSubmit);
  TEMP_IDS.forEach((id) => $(id).addEventListener("input", () => (tempsEdited = true)));
}

function fillCrops() {
  const crops = META.crops_by_country[$("country").value];
  $("crop-list").innerHTML = crops.map((c) => `<option value="${c}">`).join("");
  if (!crops.includes($("crop").value)) $("crop").value = "";
}

function fillArea() {
  const typical = META.typical_area_ha[$("country").value]?.[$("crop").value];
  if (typical) {
    $("area").value = Math.round(typical);
    $("area-hint").textContent = `Typical recent area: ${Number(typical).toLocaleString("en-IN")} ha`;
  } else {
    $("area-hint").textContent = "";
  }
}

async function fillTemps() {
  const year = parseInt($("year").value, 10);
  if (!year) return;
  try {
    const t = await api(`/temps/${encodeURIComponent($("country").value)}/${year}`);
    TEMP_IDS.forEach((id) => ($(id).value = t.temps[id]));
    tempsEdited = false;
    $("temp-source").textContent = t.source === "recorded"
      ? `Recorded values for ${year}. Edit to test a “what-if”.`
      : `No record for ${year}, so these are the ${t.source}. Edit to test a scenario.`;
  } catch (e) { /* leave fields as they are */ }
}

// ---------- predict ----------
async function onSubmit(e) {
  e.preventDefault();
  $("error").textContent = "";
  const payload = {
    country: $("country").value,
    crop: $("crop").value.trim(),
    year: parseInt($("year").value, 10),
    area_harvested_ha: parseFloat($("area").value),
  };
  if (tempsEdited) TEMP_IDS.forEach((id) => { if ($(id).value !== "") payload[id] = parseFloat($(id).value); });

  $("submit").disabled = true; $("submit").textContent = "Predicting…";
  try {
    const [r, hist] = await Promise.all([
      api("/predict", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) }),
      api(`/history/${encodeURIComponent(payload.country)}/${encodeURIComponent(payload.crop)}`),
    ]);
    showResult(r, hist);
  } catch (err) {
    $("error").textContent = err.message;
  } finally {
    $("submit").disabled = false; $("submit").textContent = "Predict yield";
  }
}

function showResult(r, hist) {
  $("empty").hidden = true; $("result").hidden = false;
  $("r-yield").textContent = fmt(r.predicted_yield_t_ha, 2);
  $("r-prod").textContent = Number(r.estimated_production_t).toLocaleString("en-IN", { maximumFractionDigits: 0 });
  if (r.last_actual_yield_t_ha != null) {
    const diff = ((r.predicted_yield_t_ha / r.last_actual_yield_t_ha) - 1) * 100;
    $("r-compare").textContent =
      `Last recorded yield (${r.last_actual_year}): ${fmt(r.last_actual_yield_t_ha, 2)} t/ha, ` +
      `so this prediction is ${diff >= 0 ? "+" : ""}${diff.toFixed(1)}% vs that. Temperatures: ${r.temperature_source}.`;
  }
  $("chart-title").textContent = `${r.crop} yield in ${r.country}, t/ha`;
  drawChart(hist, r);
  $("table").innerHTML = "<table><tr><th>Year</th><th>t/ha</th></tr>" +
    hist.years.map((y, i) => `<tr><td>${y}</td><td>${fmt(hist.yield_t_ha[i], 3)}</td></tr>`).reverse().join("") +
    "</table>";
}

// ---------- small SVG line chart with hover ----------
function drawChart(hist, r) {
  const W = 640, H = 260, m = { t: 12, r: 16, b: 26, l: 44 };
  const xs = [...hist.years, r.year], ys = [...hist.yield_t_ha, r.predicted_yield_t_ha];
  const x0 = Math.min(...xs), x1 = Math.max(...xs);
  const yStep = niceStep(Math.max(...ys) * 1.05 / 4);
  const yMax = yStep * Math.ceil(Math.max(...ys) * 1.05 / yStep);
  const X = (v) => m.l + ((v - x0) / Math.max(1, x1 - x0)) * (W - m.l - m.r);
  const Y = (v) => H - m.b - (v / yMax) * (H - m.t - m.b);

  const yTicks = []; for (let t = 0; t <= yMax + 1e-9; t += yStep) yTicks.push(t);
  const step = Math.max(5, Math.ceil((x1 - x0) / 6 / 5) * 5);
  const xTicks = []; for (let y = Math.ceil(x0 / step) * step; y <= x1; y += step) xTicks.push(y);

  const path = hist.years.map((y, i) => `${i ? "L" : "M"}${X(y).toFixed(1)},${Y(hist.yield_t_ha[i]).toFixed(1)}`).join("");

  $("chart").innerHTML = `
    <svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Yield history line chart with prediction point">
      <g class="axis">
        ${yTicks.map((t) => `<line class="gridline" x1="${m.l}" x2="${W - m.r}" y1="${Y(t)}" y2="${Y(t)}"/>
          <text x="${m.l - 8}" y="${Y(t) + 4}" text-anchor="end">${fmtTick(t)}</text>`).join("")}
        ${xTicks.map((t) => `<text x="${X(t)}" y="${H - 6}" text-anchor="middle">${t}</text>`).join("")}
      </g>
      <path class="line" d="${path}"/>
      <line class="hover-line" id="hl" y1="${m.t}" y2="${H - m.b}" visibility="hidden"/>
      <circle class="hover-dot" id="hd" r="4" visibility="hidden"/>
      <circle class="pred" cx="${X(r.year)}" cy="${Y(r.predicted_yield_t_ha)}" r="6"/>
      <rect id="hit" x="${m.l}" y="0" width="${W - m.l - m.r}" height="${H}" fill="transparent"/>
    </svg>
    <div class="tooltip" id="tt" hidden></div>`;

  const svg = $("chart").querySelector("svg"), tt = $("tt");
  svg.querySelector("#hit").addEventListener("mousemove", (ev) => {
    const pt = svg.createSVGPoint(); pt.x = ev.clientX; pt.y = ev.clientY;
    const loc = pt.matrixTransform(svg.getScreenCTM().inverse());
    const yr = x0 + ((loc.x - m.l) / (W - m.l - m.r)) * (x1 - x0);
    let best = { d: Infinity };
    xs.forEach((y, i) => { const d = Math.abs(y - yr); if (d < best.d) best = { d, i }; });
    const isPred = best.i === xs.length - 1;
    const cx = X(xs[best.i]), cy = Y(ys[best.i]);
    svg.querySelector("#hl").setAttribute("x1", cx); svg.querySelector("#hl").setAttribute("x2", cx);
    svg.querySelector("#hl").setAttribute("visibility", "visible");
    const hd = svg.querySelector("#hd");
    hd.setAttribute("cx", cx); hd.setAttribute("cy", cy); hd.setAttribute("visibility", isPred ? "hidden" : "visible");
    const scale = svg.clientWidth / W;
    tt.hidden = false; tt.style.left = cx * scale + "px"; tt.style.top = cy * scale + "px";
    tt.textContent = `${xs[best.i]}${isPred ? " (predicted)" : ""}: ${fmt(ys[best.i], 2)} t/ha`;
  });
  svg.querySelector("#hit").addEventListener("mouseleave", () => {
    tt.hidden = true;
    svg.querySelector("#hl").setAttribute("visibility", "hidden");
    svg.querySelector("#hd").setAttribute("visibility", "hidden");
  });
}

function niceStep(v) {
  const p = Math.pow(10, Math.floor(Math.log10(v)));
  for (const k of [1, 2, 2.5, 5, 10]) if (k * p >= v) return k * p;
  return 10 * p;
}
const fmtTick = (t) => (Number.isInteger(+t.toFixed(6)) ? t.toFixed(0) : t >= 1 ? t.toFixed(1) : +t.toFixed(2) + "");

init();
