"""
Step 11 — Backend Development (FastAPI)

Run from the project root:
    uvicorn backend.main:app --reload
Then open http://127.0.0.1:8000  (UI)  or  http://127.0.0.1:8000/docs  (Swagger API docs)
"""
from pathlib import Path
import json
from typing import Literal, Optional

import joblib
import numpy as np
import pandas as pd
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

ROOT = Path(__file__).resolve().parent.parent
MODEL_DIR = ROOT / "model"
FRONTEND_DIR = ROOT / "frontend"

# ---------- load model + metadata once at startup ----------
model = joblib.load(MODEL_DIR / "crop_yield_model.joblib")
meta = json.loads((MODEL_DIR / "model_meta.json").read_text())
history = pd.read_csv(MODEL_DIR / "yield_history.csv")
TEMP_COLS = meta["temp_columns"]
LAST_YEAR = meta["year_range"][1]

app = FastAPI(
    title="Crop Yield Predictor API",
    description="Predicts crop yield (t/ha) for India and China from crop, year, area and temperature change.",
    version="1.0.0",
)

# Allow a frontend hosted elsewhere (e.g. a different port or domain) to call the API
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


# ---------- request / response schemas ----------
class PredictRequest(BaseModel):
    country: Literal["India", "China"]
    crop: str = Field(..., examples=["Rice"])
    year: int = Field(..., ge=1961, le=2050, examples=[2024])
    area_harvested_ha: float = Field(..., gt=0, examples=[47_000_000])
    # Temperature change vs 1951-1980 baseline (°C). Leave empty to use recorded values for that year.
    temp_change_annual_c: Optional[float] = Field(None, ge=-5, le=8)
    temp_change_djf_c: Optional[float] = Field(None, ge=-5, le=8)
    temp_change_mam_c: Optional[float] = Field(None, ge=-5, le=8)
    temp_change_jja_c: Optional[float] = Field(None, ge=-5, le=8)
    temp_change_son_c: Optional[float] = Field(None, ge=-5, le=8)


class PredictResponse(BaseModel):
    country: str
    crop: str
    year: int
    predicted_yield_t_ha: float
    estimated_production_t: float
    temperatures_used: dict
    temperature_source: str
    last_actual_yield_t_ha: Optional[float]
    last_actual_year: Optional[int]


def default_temps(country: str, year: int):
    """Recorded temps for that year; for future years, the average of the last 5 recorded years."""
    weather = meta["weather"][country]
    if str(year) in weather:
        return weather[str(year)], "recorded"
    years = sorted(int(y) for y in weather)
    recent = [weather[str(y)] for y in years[-5:]]
    return [round(float(v), 3) for v in np.mean(recent, axis=0)], f"average of {years[-5]}–{years[-1]}"


# ---------- API endpoints ----------
@app.get("/health")
def health():
    return {"status": "ok", "model_loaded": model is not None}


@app.get("/meta")
def get_meta():
    """Everything the frontend needs to build its form."""
    return {
        "countries": list(meta["crops_by_country"].keys()),
        "crops_by_country": meta["crops_by_country"],
        "typical_area_ha": meta["typical_area_ha"],
        "year_range": meta["year_range"],
        "test_metrics": meta["test_metrics"],
        "baseline_metrics": meta["baseline_metrics"],
        "model": meta["model"],
    }


@app.get("/temps/{country}/{year}")
def get_temps(country: str, year: int):
    if country not in meta["weather"]:
        raise HTTPException(404, f"Unknown country '{country}'")
    vals, source = default_temps(country, year)
    return {"temps": dict(zip(TEMP_COLS, vals)), "source": source}


@app.get("/history/{country}/{crop}")
def get_history(country: str, crop: str):
    h = history[(history.country == country) & (history.crop == crop)].sort_values("year")
    if h.empty:
        raise HTTPException(404, f"No history for {crop} in {country}")
    return {"years": h.year.tolist(), "yield_t_ha": h.yield_t_ha.round(4).tolist()}


@app.post("/predict", response_model=PredictResponse)
def predict(req: PredictRequest):
    if req.crop not in meta["crops_by_country"][req.country]:
        raise HTTPException(422, f"'{req.crop}' is not grown in {req.country} in this dataset")

    defaults, source = default_temps(req.country, req.year)
    given = [getattr(req, c) for c in TEMP_COLS]
    temps = [g if g is not None else d for g, d in zip(given, defaults)]
    if any(g is not None for g in given):
        source = "user input" if all(g is not None for g in given) else f"user input + {source}"

    row = {"country": req.country, "crop": req.crop, "year": req.year,
           "log_area": float(np.log1p(req.area_harvested_ha)), **dict(zip(TEMP_COLS, temps))}
    X = pd.DataFrame([row])[meta["features"]]
    yield_pred = float(np.expm1(model.predict(X))[0])

    h = history[(history.country == req.country) & (history.crop == req.crop)].sort_values("year")
    last = h.iloc[-1] if not h.empty else None

    return PredictResponse(
        country=req.country, crop=req.crop, year=req.year,
        predicted_yield_t_ha=round(yield_pred, 4),
        estimated_production_t=round(yield_pred * req.area_harvested_ha, 1),
        temperatures_used=dict(zip(TEMP_COLS, [round(float(t), 3) for t in temps])),
        temperature_source=source,
        last_actual_yield_t_ha=None if last is None else float(last.yield_t_ha),
        last_actual_year=None if last is None else int(last.year),
    )


# ---------- Step 13 — serve the frontend from the same server ----------
app.mount("/static", StaticFiles(directory=FRONTEND_DIR), name="static")


@app.get("/", include_in_schema=False)
def index():
    return FileResponse(FRONTEND_DIR / "index.html")
