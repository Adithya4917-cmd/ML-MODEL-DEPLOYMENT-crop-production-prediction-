#!/usr/bin/env bash
# One-command local start (macOS / Linux)
set -e
cd "$(dirname "$0")"
[ -d .venv ] || python3 -m venv .venv
source .venv/bin/activate
pip install -q -r requirements.txt
echo ""
echo "  Local URL:   http://127.0.0.1:8000"
echo "  API docs:    http://127.0.0.1:8000/docs"
echo ""
uvicorn backend.main:app --host 0.0.0.0 --port 8000 --reload
